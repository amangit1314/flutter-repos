import express, { Request, Response } from 'express';
import MessageResponse from '../interfaces/MessageResponse';
import * as middlewares from '../middlewares';
import { logOut, loginUser, registerUser } from './users/users.controller';
const router = express.Router();

router.get<{}, MessageResponse>('/', (req: Request, res: Response) => {
    res.json({
        message: 'API - 👋🌎🌍🌏',
    });
});

// router.use('/courses',);
// router.use('/companies',);
// router.use('/courses/course:id/',);

// router.use('/users',);
router.post('/users/register', registerUser);
router.post('/users/login', loginUser);
router.post('/users/logout', logOut,);
router.get("/current", middlewares.validateToken, loginUser);

// router.use('/jobs',);

// router.use('/user:id/profile',);

export default router;
