const asyncHandler = require("express-async-handler");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { PrismaClient, Prisma } = require('@prisma/client');
const prisma = new PrismaClient();
import { Request, Response } from 'express';

//@desc Get all users
//@route GET /api/v1/users/
//@access public
export const getUsers = asyncHandler(async (req: Request, res: Response) => {
    const users = await prisma.user.findMany();
    res.json(users);
});

//@desc Register a user
//@route POST /api/users/register
//@access public
export const registerUser = async (req: Request, res: Response) => {
    const { email, username, password } = req.body;

    if (!email || !username || !password) {
        return res.status(400).json({ message: "All fields are mandatory!" });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const createdUser = await prisma.user.create({
            data: {
                email,
                username,
                password: hashedPassword,
            },
        });

        const accessToken = jwt.sign(
            {
                user: {
                    id: createdUser.id,
                    email: createdUser.email,
                    username: createdUser.username,
                },
            },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: "15m" }
        );

        res.status(201).json({
            message: "Registration is succesful",
            _id: createdUser.id,
            email: createdUser.email,
            accessToken,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to register user" });
    }
};

// //@desc Login user
// //@route POST /api/v1/users/login
// //@access public
// export const loginUser = async (req: Request, res: Response) => {
//     const { email, password } = req.body;

//     try {
//         // Find user by email
//         const user = await prisma.user.findOne({ email });

//         // If user not found
//         if (!user) {
//             return res.status(401).json({ message: 'Authentication failed. User not found.' });
//         }

//         // Compare password
//         const isMatch = await bcrypt.compare(password, user.password);

//         // If password not matched
//         if (!isMatch) {
//             return res.status(401).json({ message: 'Authentication failed. Wrong password.' });
//         }

//         // Create and sign JWT token
//         const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

//         // Set cookie with token
//         res.cookie('token', token, { httpOnly: true, maxAge: 3600000 });

//         // Return success response
//         return res.status(200).json({ message: 'Authentication successful.' });

//     } catch (error) {
//         console.log(error);
//         return res.status(500).json({ message: 'Internal server error.' });
//     }
// };

export const loginUser = async (req: Request, res: Response) => {
    const { email, password } = req.body;

    try {
        // Find user by email
        const user = await prisma.user.findOne({ where: { email } });

        // If user not found
        if (!user) {
            return res.status(401).json({ message: 'Authentication failed. User not found.' });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);

        // If password not matched
        if (!isMatch) {
            return res.status(401).json({ message: 'Authentication failed. Wrong password.' });
        }

        // Create and sign JWT token
        const token = jwt.sign({ userId: user.uid }, process.env.JWT_SECRET, { expiresIn: '1h' });

        // Set cookie with token
        res.cookie('token', token, { httpOnly: true, maxAge: 3600000 });

        // Return success response
        return res.status(200).json({ message: 'Authentication successful.', token, ...user });
        // (... user) is to get all the necessary data only
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: 'Internal server error.' });
    }
}


//@desc Current user info
//@route POST /api/users/current
//@access private
// export const currentUser = asyncHandler(async (req: Request, res: Response) => {
//     res.json(req.user);
// });

//@desc Logout user 
//@route Delete /api/users/logOut
//@access private
export const logOut = asyncHandler(async (req: Request, res: Response) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out' });
});