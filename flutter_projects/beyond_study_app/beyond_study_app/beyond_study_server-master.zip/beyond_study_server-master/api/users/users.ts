import { getUsers, logOut } from "./users.controller";

const express = require("express");
const {
    registerUser,
    currentUser,
    loginUser,
} = require("../controllers/userController");
const validateToken = require("../middlewares/validateTokenHandler");

const router = express.Router();

router.get("/", getUsers);

router.post("/register", registerUser);

router.post("/login", loginUser);

router.get("/current", validateToken, currentUser);

router.post("/logOut", logOut);

module.exports = router;
