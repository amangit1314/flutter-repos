-- CreateTable
CREATE TABLE "user" (
    "uid" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,

    CONSTRAINT "user_pkey" PRIMARY KEY ("uid")
);

-- CreateTable
CREATE TABLE "course" (
    "cid" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "teachingInstituteLogo" TEXT NOT NULL,
    "teachingInstitutionName" TEXT NOT NULL,
    "price" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "category" TEXT[],
    "subcategory" TEXT[],
    "author" TEXT[],
    "authorImage" TEXT[],
    "authorDescription" TEXT[],
    "authorEmail" TEXT[],
    "authorPhone" TEXT[],
    "authorWebsite" TEXT NOT NULL,
    "usersUid" TEXT,

    CONSTRAINT "course_pkey" PRIMARY KEY ("cid")
);

-- CreateTable
CREATE TABLE "job" (
    "jid" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "company" TEXT NOT NULL,
    "location" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "category" TEXT[],
    "subcategory" TEXT[],
    "author" TEXT[],
    "authorImage" TEXT[],
    "authorEmail" TEXT[],
    "authorPhone" TEXT[],
    "authorWebsite" TEXT NOT NULL,

    CONSTRAINT "job_pkey" PRIMARY KEY ("jid")
);

-- AddForeignKey
ALTER TABLE "course" ADD CONSTRAINT "course_usersUid_fkey" FOREIGN KEY ("usersUid") REFERENCES "user"("uid") ON DELETE SET NULL ON UPDATE CASCADE;
